package com.springSemester.ComponentAnnotation.petStore;

import org.springframework.stereotype.Component;

@Component
public class Snail extends Pet{
}
